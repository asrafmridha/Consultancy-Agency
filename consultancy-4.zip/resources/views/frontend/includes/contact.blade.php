
<section id="contact-quote" class="contact-quote section-space section-gap" data-aos="fade-up">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h3 class="contact-quote__sub-title font-weight-normal">Get a Quote</h3>
                <h1 class="contact-quote__title text-uppercase font-weight-bold">Have any project on mind?</h1>
                <p class="contact-quote__text">let's contact with our experts</p>
                <a href="#" class="primary-btn d-inline-block text-uppercase mt-2">Get a Quote Now</a>
            </div>
        </div>
    </div>
</section>