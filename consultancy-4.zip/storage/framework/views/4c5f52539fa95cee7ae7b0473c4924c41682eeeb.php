<!DOCTYPE html>
<html class="loading <?php echo e((themesetting(Auth::id()) == null) ? 'light-layout' : themesetting(Auth::id())->theme); ?>" lang="en" data-textdirection="ltr">
<!-- BEGIN: Head-->

<head>
    <?php echo $__env->make('backend.includes.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- BEGIN: Vendor CSS-->

    <?php echo $__env->make('backend.includes.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="vertical-layout vertical-menu-modern  navbar-floating footer-static 

    <?php if(themesetting(Auth::id()) == null): ?>
      menu-expanded
    <?php else: ?>
         <?php if(themesetting(Auth::id())->nav == 'collapsed'): ?>
            menu-collapsed
         <?php else: ?>
            menu-expanded
        <?php endif; ?>
    <?php endif; ?> 

" data-open="click" data-menu="vertical-menu-modern" data-col="">

    <!-- BEGIN: Header-->
    <?php echo $__env->make('backend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: Header-->


    <!-- BEGIN: Main Menu-->
    <?php echo $__env->make('backend.includes.mainmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: Main Menu-->

    
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper <?php echo $__env->yieldContent('content-wrapper-class'); ?>">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <?php echo $__env->yieldContent('breadcrumb'); ?>
                            
                        </div>
                    </div>
                </div>
                <div class="content-header-right text-md-right col-md-3 col-12 d-md-block">
                    <div class="form-group breadcrumb-right">

                    </div>
                </div>
            </div>
            <div class="content-body">
                           
                               <?php echo $__env->yieldContent('content'); ?>
                           
                       </div>
        </div>
    </div>

    <!-- BEGIN: Content-->
    
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <!-- BEGIN: Footer-->
    <?php echo $__env->make('backend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    
    <?php echo $__env->make('backend.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: Page JS-->

    <script>
        $(window).on('load', function() {
            if (feather) {
                feather.replace({
                    width: 14,
                    height: 14
                });
            }
        })
    </script>
</body>
<!-- END: Body-->

</html>
<?php /**PATH C:\Users\DCL\OneDrive\Desktop\consultancy-4\resources\views/backend/mastaring/master.blade.php ENDPATH**/ ?>