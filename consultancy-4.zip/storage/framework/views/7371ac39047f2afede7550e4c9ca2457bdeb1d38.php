<!-- All Scripts -->
<script src="<?php echo e(asset('frontend')); ?>/assets/js/jquery-1.12.4.min.js"></script>
<script src="<?php echo e(asset('frontend')); ?>/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('frontend')); ?>/assets/plugins/counter-up/js/waypoints.min.js"></script>
<script src="<?php echo e(asset('frontend')); ?>/assets/plugins/counter-up/js/jquery.counterup.min.js"></script>
<script src="<?php echo e(asset('frontend')); ?>/assets/plugins/mixitup/js/mixitup.min.js"></script>
<script src="<?php echo e(asset('frontend')); ?>/assets/plugins/slick-slider/js/slick.js"></script>
<script src="<?php echo e(asset('frontend')); ?>/assets/plugins/aos/js/aos.js"></script>
<script src="<?php echo e(asset('frontend')); ?>/assets/plugins/venobox/js/venobox.min.js"></script>
<script src="<?php echo e(asset('frontend')); ?>/assets/js/script.js"></script>



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<?php echo $__env->yieldContent('js'); ?><?php /**PATH C:\Users\DCL\OneDrive\Desktop\consultancy-4\resources\views/frontend/includes/script.blade.php ENDPATH**/ ?>