
<?php $__env->startSection('content'); ?>

<section class="sub-banner section-gap">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h1 class="sub-banner__title text-uppercase font-weight-bold">CASE STUDIES</h1>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb bg-transparent justify-content-center mb-0">
                      <li class="breadcrumb-item"><a href="./index.html" class="breadcrumb-link">Home</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Case Studies</li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</section>

<section class="case-studies case-studies--secondary section-gap">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <ul class="case-studies__navigation nav nav-pills flex-column flex-sm-row align-items-center justify-content-center mb-4" id="pills-tab" role="tablist">
                    <li class="case-studies__navigation__item nav-item" role="presentation">
                          <button class="case-studies__navigation__link nav-link bg-transparent border-0 active" data-mixitup-control data-filter="all" data-toggle="pill" role="tab" aria-selected="true"><?php echo e($recentwork_button->buisness_finance); ?></button>
                    </li>
                    <li class="case-studies__navigation__item nav-item" role="presentation">
                          <button class="case-studies__navigation__link nav-link bg-transparent border-0" data-mixitup-control data-filter=".customer-support" data-toggle="pill" role="tab" aria-selected="false"><?php echo e($recentwork_button->customer_support); ?></button>
                    </li>
                    <li class="case-studies__navigation__item nav-item" role="presentation">
                        <button class="case-studies__navigation__link nav-link bg-transparent border-0" data-mixitup-control data-filter="all" data-toggle="pill" role="tab" aria-selected="false"><?php echo e($recentwork_button->financial_service); ?></button>
                    </li>
                    <li class="case-studies__navigation__item nav-item" role="presentation">
                          <button class="case-studies__navigation__link nav-link bg-transparent border-0" data-mixitup-control data-filter=".business-strategy" data-toggle="pill" role="tab" aria-selected="false"><?php echo e($recentwork_button->buisness_stargey); ?></button>
                    </li>
                    <li class="case-studies__navigation__item nav-item" role="presentation">
                          <button class="case-studies__navigation__link nav-link bg-transparent border-0" data-mixitup-control data-filter=".sales-service" data-toggle="pill" role="tab" aria-selected="false"><?php echo e($recentwork_button->sale_service); ?></button>
                    </li>
                </ul>
            </div>
            <div class="col-12">
                <div class="case-studies__container row">
                    <?php $__currentLoopData = $recentwork; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <div class="col-lg-4 col-sm-6 mix business-strategy">
                                 
                        <div class="case-studies__block position-relative">
                            <img  height="300px" width="200px" src="<?php echo e(asset('uploads/recentwork/'. $item->image )); ?>" alt="Case Studies Image" class="case-studies__block__image w-100">
                            <div class="case-studies__block__overlay d-flex align-items-end w-100 h-100 position-absolute">
                                <div class="case-studies__block__overlay__content d-flex align-items-end w-100">
                                    <div class="case-studies__block__overlay__content__text position-relative flex-grow-1">
                                        <h4 class="case-studies__block__overlay__sub-title font-weight-normal side-line side-line--40 mb-1"><?php echo e($item->title); ?></h4>
                                        <h3 class="case-studies__block__overlay__title mb-0 mr-4 text-uppercase">
                                            <a href="./case-study.html" class="case-studies__block__overlay__title__link d-inline-block"><?php echo e($item->short_description); ?></</a>
                                        </h3>
                                    </div>
                                    <a href="<?php echo e(asset('uploads/recentwork/'. $item->image )); ?>" data-gall="case-studies" class="plus-btn venobox d-inline-flex align-items-center justify-content-center flex-shrink-0 stretched-link">
                                        <i class="flaticon-add"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/frontend/pages/case.blade.php ENDPATH**/ ?>