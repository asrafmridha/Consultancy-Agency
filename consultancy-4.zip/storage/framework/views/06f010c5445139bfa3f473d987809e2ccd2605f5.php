
<?php $__env->startSection('feedback','active'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <h2 class="content-header-title float-left mb-0">Admin Dashboard</h2>
    <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="">Feedback Table </a>
            </li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 








          <!-- Dark Tables start -->
<div class="row" id="white-table">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Total Feedback (<?php echo e($data->count()); ?>)</h4>
            </div>  
                <div class="table-responsive " >
                    <table class="table table-white " >
                        <thead>
                            <?php if($data->isEmpty()): ?>
                            <th><h2 class="alert alert-danger">Data Not Found</h2></th>
                            <?php else: ?>
                            <tr>
                                <th>Image</th>
                                <th>Short Description</th>
                                <th>Client Name</th>
                                <th>Designation</th>
                                <th>Star</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <img height="80px" width="80px" src="<?php echo e(asset('uploads/client/'.$item->image)); ?>" class="mr-75" alt="something went wrong" /> 
                                    </td>
                                    <td><?php echo $item->short_description; ?></td>
                                    <td> <?php echo e($item->client_name); ?></td>
                                    <td>  <?php echo e($item->designation); ?></td> 
                                    <td> <?php echo e($item->star); ?> </td>             
                                        <td>
                                            <div class="dropdown">
                                                <button type="button" class="btn btn-sm text-dark dropdown-toggle hide-arrow" data-toggle="dropdown">
                                                    <i data-feather="more-vertical"></i>
                                                </button>
                                                <div class="dropdown-menu">
                                                    <a href="<?php echo e(route('feedback.updateview',$item->id)); ?>" class="dropdown-item" href="javascript:void(0);">
                                                        <i data-feather="edit-2" class="mr-50"></i>
                                                        <span>Edit</span>
                                                    </a>
                                                    <button data-target="#deleteModalfeedback__<?php echo e($item->id); ?>" data-toggle="modal" type="submit" class="dropdown-item" href="javascript:void(0);">
                                                        <i data-feather="trash" class="mr-50"></i>
                                                        <span>Delete</span>
                                                    </button>
                                                </div>
                                            </div>                  
                                        </td>
                                </tr>

                     <!-- Modal for Feedback  delete -->
<div class="modal fade" id="deleteModalfeedback__<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Confirmation Message</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>
           
                   <div class="modal-body text-white bg-dark">
                        <form action="<?php echo e(route('feedback.destroy',$item->id)); ?>" method="POST">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                            Are you sure want to delete this Service?
                    
                    <div class="modal-footer">
                        <a type="button" class="btn btn-secondary" data-dismiss="modal">Close</a>
                        <button type="submit" class="btn btn-primary deletemodalservicebutton">Confirm</button>
                    </div>
                        </form>
            </div>
        </div>
    </div>
</div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php endif; ?>    
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- Dark Tables end -->

<?php $__env->stopSection(); ?>


        
<?php echo $__env->make('backend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_all_project\consultancy-4\resources\views/backend/clientfeedback/table_clientfeedback.blade.php ENDPATH**/ ?>