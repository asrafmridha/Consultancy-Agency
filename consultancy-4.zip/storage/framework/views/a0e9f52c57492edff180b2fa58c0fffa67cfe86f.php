<div class="row match-height">
    <!-- Medal Card -->
    <div class="col-xl-4 col-md-6 col-12">
        <div class="card card-congratulation-medal">
            <div class="card-body">
                <h5>Congratulations 🎉 <?php echo e(Auth::user()->name); ?></h5>
                <h4 class="card-text ">You have <?php echo e($totalmessage); ?> Message</h4>
                <h3 class="mb-75 mt-4 pt-50">
                    <a href="javascript:void(0);">Unread Message(<?php echo e($message); ?> )</a>
                </h3>
                <a href="<?php echo e(route('customer.message.show')); ?>" class="btn btn-primary">View Message</a>
                
                
            </div>
        </div>
    </div>
    <!--/ Medal Card -->

    <!-- Statistics Card -->
    <div class="col-xl-8 col-md-6 col-12">
        <div class="card card-statistics mr-5">
            <div class="card-header ">
                <h4 class="card-title">Welcome Back <?php echo e(Auth::user()->name); ?></h4>
                


                
            </div>
            <div class="card-body statistics-body">
                <div class="row">
                    <div class="col-xl-3 col-sm-6 col-12 mb-2 mb-xl-0">
                        <div class="media">
                            <div class="avatar bg-light-primary mr-2">
                                <div class="avatar-content">
                                    <i data-feather='slack'></i>
                                </div>
                            </div>
                            <div class="media-body my-auto">
                                <h4 class="font-weight-bolder mb-0"><?php echo e($service); ?></h4>
                                <p class="card-text font-small-3 mb-0">Service</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12 mb-2 mb-xl-0">
                        <div class="media">
                            <div class="avatar bg-light-info mr-2">
                                <div class="avatar-content">
                                    <i data-feather='users'></i>
                                </div>
                            </div>
                            <div class="media-body my-auto">
                                <a href="<?php echo e(route('admin.teamview')); ?>" class="font-weight-bolder mb-0"><?php echo e($team); ?>

                                <p class="card-text font-small-3 mb-0">Team Member</p> </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12 mb-2 mb-sm-0">
                        <div class="media">
                            <div class="avatar bg-light-danger mr-2">
                                <div class="avatar-content">
                                    <i data-feather='activity'></i>
                                </div>
                            </div>
                            <div class="media-body my-auto">
                                <a href="<?php echo e(route('admin.managerecentwork')); ?>" class="font-weight-bolder mb-0"><?php echo e($recent_work); ?>

                                <p class="card-text font-small-3 mb-0">Recent Work</p> </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6 col-12">
                        <div class="media">
                            <div class="avatar bg-light-success mr-2">
                                <div class="avatar-content">
                                    <i data-feather='award'></i>
                                </div>
                            </div>
                            <div class="media-body my-auto">
                                <a href="<?php echo e(route('feedback.show')); ?>" class="font-weight-bolder mb-0"><?php echo e($feedback); ?>

                                <p class="card-text font-small-3 mb-0">Feedback</p> </a>
                            </div>
                        </div>
                    </div>

                   <div class="m-2 ">
                    <a  href="<?php echo e(route('admin.serviceview')); ?>" class="btn btn-primary ">Add Service</a>
                    <a  href="<?php echo e(route('admin.teamview')); ?>" class="btn btn-primary ">Add Team</a>
                    <a  href="<?php echo e(route('admin.addrecentwork')); ?>" class="btn btn-primary  ">Add Recent Work</a>
                    <a  href="<?php echo e(route('feedback.addview')); ?>" class="btn btn-primary ">Add Feedback</a>
                   </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ Statistics Card -->
</div>


<div class="col-12">
    <div class="card">
        <div class="card-header d-flex flex-sm-row flex-column justify-content-md-between align-items-start justify-content-start">
        
            <div class="d-flex align-items-center flex-wrap mt-sm-0 mt-1">
                <h5 class="font-weight-bolder mb-0 mr-1"></h5>
            
            </div>
        </div>
        <div class="card-body">
            <div id="line-chart"></div>
        </div>
    </div>
</div>












<?php /**PATH C:\Users\DCL\OneDrive\Desktop\consultancy-4\resources\views/backend/includes/content.blade.php ENDPATH**/ ?>