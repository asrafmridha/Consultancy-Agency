<nav class="header-navbar navbar navbar-expand-lg align-items-center floating-nav 
    <?php if(themesetting(Auth::id()) == null): ?>
        navbar-light
    <?php else: ?>
        <?php if(themesetting(Auth::id())->theme == 'light-layout'): ?>
            navbar-light
        <?php else: ?>
            navbar-dark
        <?php endif; ?>
    <?php endif; ?>    
    ">
    <div class="navbar-container d-flex content">
        <div class="bookmark-wrapper d-flex align-items-center">
          
        </div>
        <ul class="nav navbar-nav align-items-center ml-auto">
            
            <li class="nav-item d-none d-lg-block">
                <a  id="dark" class="nav-link nav-link-style">
                    <?php if(themesetting(Auth::id()) == null): ?>
                        <i class="ficon" data-feather="sun"></i>
                        <?php else: ?>
                        <?php if(themesetting(Auth::id())->theme == 'dark-layout'): ?> 
                         <i class="ficon"
                         data-feather="sun"></i>
                        <?php else: ?>
                         <i class="ficon"
                         data-feather="moon"></i>
                    
                        <?php endif; ?>
                    <?php endif; ?> 
                    
                </a>
                </li>
            <li class="nav-item nav-search"><a class="nav-link nav-link-search"><i class="ficon" data-feather="search"></i></a>
                
                    
                    <div class="search-input">
                        <div class="search-input-icon"><i data-feather="search"></i></div>
                            <input class="form-control input" type="text" placeholder="Search Menu" tabindex="-1" data-search="search" id="allsearch" >
                        <div class="search-input-close">
                            <i data-feather="x"></i>
                        </div>
                        <ul class="search-list search-list-main" id="searchlist" >
                            
                        </ul>
                    </div>
                
            </li>
            
            
            <li class="nav-item dropdown dropdown-user"><a href="<?php echo URL::to('/'); ?>" class="nav-link dropdown-toggle dropdown-user-link" id="dropdown-user" href="javascript:void(0);" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="user-nav d-sm-flex d-none">
                        <span class="user-name font-weight-bolder"><?php echo e(Auth::user()->name); ?></span>
                        <span class="user-status"><?php echo e(Auth::user()->email); ?></span>
                    </div>
                    <span >
                        <img class="round" src="<?php echo e(asset('uploads/user/'.Auth::user()->image)); ?>" alt="image" height="40" width="40">
                    </span>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-user">
                    <a class="dropdown-item" href="<?php echo e(route('my-profile')); ?>">
                        <i class="mr-50" data-feather="user"></i> Profile
                    </a>
                    
                    
                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                    <button type="submit" class="dropdown-item" ><i class="mr-50" data-feather="power"></i> Logout</button>
                </form>
                </div>
            </li>
        </ul>
        
    </div>
</nav>



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
    jQuery(document).ready(function(){

    jQuery(document).on("keyup","#allsearch", function(){
       var search= jQuery(this).val();
       $.ajax({
            type: "GET",
            url: "/admin/all/search/"+search,
            success: function (response) {
                $('#searchlist').html(response.view);
            }
        });
     
     });






    });

    
  
</script> 

<?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/backend/includes/header.blade.php ENDPATH**/ ?>