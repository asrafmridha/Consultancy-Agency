
    <!-- ########## START: LEFT PANEL ########## -->
    <div class="br-logo"><a href=""><span>[</span>bracket <i>plus</i><span>]</span></a></div>
    <div class="br-sideleft sideleft-scrollbar">
      <label class="sidebar-label pd-x-10 mg-t-20 op-3">Navigation</label>
      <ul class="br-sideleft-menu">
        <li class="br-menu-item">
          <a href="#" class="br-menu-link">
            <i class="menu-item-icon icon ion-ios-home-outline tx-24"></i>
            <span class="menu-item-label">Dashboard</span>
          </a><!-- br-menu-link -->
        </li><!-- br-menu-item -->

        
        <li class="br-menu-item">
          <a href="#" class="br-menu-link <?php echo $__env->yieldContent('headbarMenu'); ?> with-sub">
            <i class="menu-item-icon icon ion-ios-photos-outline tx-20"></i>
            <span class="menu-item-label">HeadBar</span>
          </a><!-- br-menu-link -->
          <ul class="br-menu-sub">
            <li class="sub-item"><a href="<?php echo e(Route('headertextview')); ?>" class="sub-link">Add Text</a></li>
            
         
            

            
            
          </ul>
        </li>

    

        <li class="br-menu-item">
          <a href="#" class="br-menu-link <?php echo $__env->yieldContent('service'); ?>  with-sub">
            <i class="menu-item-icon icon ion-ios-photos-outline tx-20"></i>
            <span class="menu-item-label">Our Service</span>
          </a><!-- br-menu-link -->
          <ul class="br-menu-sub">
            <li class="sub-item"><a href="<?php echo e(route('admin.serviceview')); ?>" class="sub-link">Add Service</a></li>


            <li class="sub-item"><a href="<?php echo e(route('admin.servicetableview')); ?>" class="sub-link">View Service</a></li>
            
          </ul>
        </li>



         <li class="br-menu-item">
          <a href="#" class="br-menu-link with-sub <?php echo $__env->yieldContent('teamview'); ?>">
            <i class="menu-item-icon icon ion-ios-photos-outline tx-20"></i>
            <span class="menu-item-label ">Team</span>
          </a><!-- br-menu-link -->
          <ul class="br-menu-sub">
            <li class="sub-item"><a href="<?php echo e(route('admin.teamview')); ?>" class="sub-link">Add Team</a></li>
            
        <li class="sub-item"><a href="<?php echo e(route('admin.teamtable')); ?>" class="sub-link">Manage Team</a></li> 
                    
          </ul>
         
        </li>  
      </ul>
        
        

      <br>
    </div><!-- br-sideleft -->
    <!-- ########## END: LEFT PANEL ########## -->

    <?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/backend/includes/leftbar.blade.php ENDPATH**/ ?>