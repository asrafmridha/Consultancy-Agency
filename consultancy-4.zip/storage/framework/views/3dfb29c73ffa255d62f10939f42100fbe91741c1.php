<!DOCTYPE html>
<html lang="en">
<head>
	<?php echo $__env->make('frontend.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- All CSS -->
	 <?php echo $__env->make('frontend.includes.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
</head>
<body>
	<!-- Preloader Section Start -->
	<div class="preloader position-fixed w-100 h-100">
		<div class="preloader__bg d-flex align-items-center justify-content-center w-100 h-100">
			<img src="<?php echo e(asset('frontend/assets/images/preloader/preloader.gif')); ?>" alt="Preloader Image" class="img-fluid">
		</div>
	</div>
	<!-- Preloader Section End -->

	<!-- Header Section Start -->

    <?php echo $__env->make('frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
	
	<!-- Header Section End -->

	<!-- Banner Section Start -->
	
	<!-- Banner Section End -->

	<!-- Our Services Section Start -->
	
	<!-- Our Services Section End -->

	<!-- About Us Section Start -->
	

	<!-- Case Studies Section Start -->
	
	<!-- Case Studies Section End -->

	<!-- Horizontal Line Section Start -->
	

	<?php echo $__env->yieldContent('content'); ?>
	<!-- Horizontal Line Section End -->

	<!-- Form and FAQ Section Start -->
	
	<!-- Form and FAQ Section End -->

	<!-- Testimonial Section Start -->
	
	<!-- Testimonial Section End -->

	<!-- Our Team Section Start -->
	
	<!-- Our Team Section End -->

	<!-- Contact Quote Section Start -->
	
	<!-- Contact Quote Section End -->

	<!-- Clients and Counter Section Start -->
	
	<!-- Clients and Counter Section End -->

	<!-- Footer Section Start -->

    <?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<!-- Footer Section End -->

	<!-- Scroll To Top Button Start -->
	<div class="scroll-top position-fixed">
		<span class="scroll-top__btn d-inline-flex align-items-center justify-content-center">
			<i class="flaticon-upload"></i>
		</span>
	</div>
	<!-- Scroll To Top Button End -->

	<!-- All Scripts -->
	<?php echo $__env->make('frontend.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/frontend/mastaring/master.blade.php ENDPATH**/ ?>