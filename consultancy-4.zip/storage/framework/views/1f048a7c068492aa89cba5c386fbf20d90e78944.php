

<?php $__env->startSection('experiencearea','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <h2 class="content-header-title float-left mb-0">Admin Dashboard</h2>
    <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="">Update Experience </a>
            </li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section >
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('experience.area.update',$data->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                       <img height="120px" width="180px" src="<?php echo e(asset('uploads/experience/'.$data->first_image)); ?>" alt="something went wrong">
                        <div class="form-group">
                            <label for="first_image">First Image</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="first_image" name="first_image" />
                                <label class="custom-file-label" for="customFile">Choose file</label>
                            </div>
                            <?php $__errorArgs = ['first_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <img height="120px" width="180px" src="<?php echo e(asset('uploads/experience/'.$data->second_image)); ?>" alt="">

                    <div class="form-group">
                            <label for="second_image">Second Image</label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="second_image" name="second_image" />
                            <label class="custom-file-label" for="customFile">Choose file</label>
                        </div>
            
                            <?php $__errorArgs = ['second_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                        <img height="120px" width="180px" src="<?php echo e(asset('uploads/experience/'.$data->side_image1)); ?>" alt="">
                    <div class="form-group">
                            <label for="side_image1">Side Image_1</label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="side_image1" name="side_image1" />
                            <label class="custom-file-label" for="customFile">Choose file</label>
                        </div>
                            <?php $__errorArgs = ['side_image1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                        <img height="120px" width="180px" src="<?php echo e(asset('uploads/experience/'.$data->side_image2)); ?>" alt="">
                    <div class="form-group">
                            <label for="side_image2">Side Image_2</label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="side_image2" name="side_image2" />
                            <label class="custom-file-label" for="customFile">Choose file</label>
                        </div>
            
                            <?php $__errorArgs = ['side_image2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                        <img height="120px" width="180px" src="<?php echo e(asset('uploads/experience/'.$data->side_image3)); ?>" alt="">

                    <div class="form-group">
                            <label for="side_image3">Side Image_3</label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="side_image3" name="side_image3" />
                            <label class="custom-file-label" for="customFile">Choose file</label>
                        </div>
 
                            <?php $__errorArgs = ['side_image3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                        <img height="120px" width="180px" src="<?php echo e(asset('uploads/experience/'.$data->side_image4)); ?>" alt="">
                    <div class="form-group">
                            <label for="side_image4">Side Image_4</label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="side_image4" name="side_image4" />
                            <label class="custom-file-label" for="customFile">Choose file</label>
                        </div>
            
                                <?php $__errorArgs = ['side_image4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
         
                            <label class="mt-1 h5" for="years">Enter Years</label>
                            <input type="number" name="years" class="text-dark  form-control name" placeholder="Enter Heading" value="<?php echo e($data->years); ?>">
                        
                            <?php $__errorArgs = ['years'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger">
                                    <?php echo e($message); ?>

                                </div>  
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label class="mt-1 h5" for="heading">Enter First Page heading</label>
                            <input type="text" name="heading" class=" text-dark  form-control image"
                            placeholder="Enter Title" value="<?php echo e($data->heading); ?>">
                        
                            <?php $__errorArgs = ['heading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger">
                            
                                    <?php echo e($message); ?>

                                </div>  
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <img height="120px" width="180px" src="<?php echo e(asset('uploads/experience/'.$data->about_first_image)); ?>" alt="something went wrong">
            
                        <div class="form-group">
                            <label for="about_first_image">About Page First Image</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="about_first_image" name="about_first_image" />
                                <label class="custom-file-label" for="customFile">Choose file</label>
                            </div>

                                <?php $__errorArgs = ['about_first_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                            <img height="120px" width="180px" src="<?php echo e(asset('uploads/experience/'.$data->about_second_image)); ?>" alt="something went wrong">
            
                        <div class="form-group">
                                <label for="about_second_image">About Page Second Image</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="about_second_image" name="about_second_image" />
                                <label class="custom-file-label" for="customFile">Choose file</label>
                            </div>
                                <?php $__errorArgs = ['about_second_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <label class="mt-1 h5" for="heading2">Enter Second Page heading</label>
                        <input type="text" name="heading2" class=" text-dark  form-control image"
                        placeholder="Enter Title" value="<?php echo e($data->heading2); ?>">
                        
                            <?php $__errorArgs = ['heading2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger">

                                    <?php echo e($message); ?>

                                </div>  
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <label class="mt-1 h5" for="heading">Enter compelte project</label>
                        <input type="text" name="compelte_project" class=" text-dark  form-control image"
                        placeholder="Enter Title" value="<?php echo e($data->compelte_project); ?>">
                        
                            <?php $__errorArgs = ['compelte_project'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger">

                                    <?php echo e($message); ?>

                                </div>  
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                        <label class="mt-1 h5" for="heading">Enter Satisfied project</label>
                        <input type="text" name="satisfied_project" class=" text-dark  form-control image"
                        placeholder="Enter Title" value="<?php echo e($data->satisfied_project); ?>">
                        
                            <?php $__errorArgs = ['satisfied_project'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger">
                    
                                    <?php echo e($message); ?>

                                </div>  
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <label class="mt-1 h5" for="heading">Enter Ongoing Project</label>
                        <input type="text" name="ongoing_project" class=" text-dark  form-control image"
                        placeholder="Enter Title" value="<?php echo e($data->ongoing_project); ?>">
                        
                            <?php $__errorArgs = ['ongoing_project'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger">
                    
                                    <?php echo e($message); ?>

                                </div>  
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <label class="m2 h5" for="title">Enter Title</label>
                        <input type="text" name="title" class=" text-dark  form-control image"
                        placeholder="Enter Title" value="<?php echo e($data->title); ?>">

                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger">
                            
                                    <?php echo e($message); ?>

                                </div>  
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <input class="mt-2" type="hidden" name="short_description" id="short_description" value="<?php echo $data->short_description; ?>" class="form-control">

                        <trix-editor  input="short_description" style="min-height: 12rem !important"><?php echo $data->short_description; ?></trix-editor>

                            <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger">
                                    <?php echo e($message); ?>

                                </div>  
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <button type="submit" class="form-control mt-1 btn-purchaseAdd btn btn-primary"> Update</button>
                        </form>
                </div>
            </div>
       </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_all_project\consultancy-4\resources\views/backend/experience/experiencearea.blade.php ENDPATH**/ ?>