
<?php $__env->startSection('content'); ?>

<section class="sub-banner section-gap">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h1 class="sub-banner__title text-uppercase font-weight-bold">SERVICE DETAILS</h1>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb bg-transparent justify-content-center mb-0">
                      <li class="breadcrumb-item"><a href="./index.html" class="breadcrumb-link">Home</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Service Details</li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</section>

<section class="service-details section-gap">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 text-center" data-aos="fade-up">
                <img src="<?php echo e(asset('uploads/service/'.$item->image)); ?>" alt="Services Support Image" class="service-details__image img-fluid">
            </div>
            <div class="col-lg-7">
                <div class="section-header text-center text-lg-left">
                    <h3 class="section-header__sub-title side-line side-line--81 mb-1"><?php echo e($title->service2_title); ?></h3>
                    <h1 class="section-header__title text-uppercase font-weight-bold"><?php echo e($title->service2_heading); ?></h1>
                </div>
                <div class="row">
                    <div class="col-xl-10 text-center text-lg-left">
                        <p class="service-details__text"><?php echo $item->short_description2; ?></p>
                    </div>
                    <div class="col-xl-11">
                        <blockquote class="service-details__blockquote bg-white" data-aos="fade-up">
                            <p class="blockquote-text"><?php echo e($item->advise); ?></p>
                            <footer class="blockquote-footer text-right"><span class="blockquote-writer position-relative"><?php echo e($item->advisor_name); ?></span></footer>
                        </blockquote>
                    </div>
                    <div class="col-12">
                        <h2 class="service-details__list-title text-uppercase"><?php echo e($item->heading); ?></h2>
                        <ul class="service-details__list mb-0">

                            <?php echo $item->point; ?>

                            
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>

    <section id="contact-quote" class="contact-quote section-space section-gap" data-aos="fade-up">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h3 class="contact-quote__sub-title font-weight-normal"><?php echo e($title->contact_heading); ?></h3>
                    <h1 class="contact-quote__title text-uppercase font-weight-bold"><?php echo e($projectidea->heading); ?></h1>
                    <p class="contact-quote__text"><?php echo e($projectidea->title); ?></p>
                    <a href="<?php echo e(route('contact')); ?>" class="primary-btn d-inline-block text-uppercase mt-2"><?php echo e($projectidea->button_text); ?></a>
                </div>
            </div>
        </div>
    </section>

    <section class="case-studies" data-aos="fade-up">
        <div class="container">
            <div class="row">
                <div class="section-header col-12 text-center">
                    <h3 class="section-header__sub-title side-line side-line--81 mb-1"><?php echo e($title->case_studies_title); ?></h3>
                    <h1 class="section-header__title text-uppercase font-weight-bold"><?php echo e($title->case_studies_heading); ?></h1>
                </div>
                <div class="col-12">
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade d-block show active" id="pills-business-finance" role="tabpanel" aria-labelledby="pills-business-finance-tab">
                            <div class="case-studies__slider row">
                                <?php $__currentLoopData = $recentwork; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="case-studies__slide col-lg-4 col-md-6">  
                                    <div class="case-studies__block position-relative">
                                        <img height="300px" width="200px" src="<?php echo e(asset('uploads/recentwork/'.$item->image)); ?>" alt="Case Studies Image" class="case-studies__block__image w-100">
                                        <div class="case-studies__block__overlay d-flex align-items-end w-100 h-100 position-absolute">
                                            <div class="case-studies__block__overlay__content d-flex align-items-end w-100">
                                                <div class="case-studies__block__overlay__content__text position-relative flex-grow-1">
                                                    <h4 class="case-studies__block__overlay__sub-title font-weight-normal side-line side-line--40 mb-1"><?php echo e($item->title); ?></h4>
                                                    <h3 class="case-studies__block__overlay__title mb-0 mr-4 text-uppercase">
                                                        <a href="./case-study.html" class="case-studies__block__overlay__title__link d-inline-block"><?php echo $item->short_description; ?></a>
                                                    </h3>
                                                </div>
                                                <a href="<?php echo e(asset('uploads/recentwork/'.$item->image)); ?>" data-gall="case-studies" class="plus-btn venobox d-inline-flex align-items-center justify-content-center flex-shrink-0 stretched-link">
                                                    <i class="flaticon-add"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div> 
                                </div>
    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="case-studies__slide col-lg-4 col-md-6">
                                    <div class="case-studies__block position-relative">
                                            <div class="case-studies__block__overlay__content d-flex align-items-end w-100">      
                                            </div>
                                        </div>
                                    </div>
                                </div>      
                            </div>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/frontend/pages/service.blade.php ENDPATH**/ ?>