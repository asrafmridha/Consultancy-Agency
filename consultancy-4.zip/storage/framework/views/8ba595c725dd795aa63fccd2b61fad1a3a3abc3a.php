<div class="main-menu menu-fixed
     <?php if(themesetting(Auth::id()) == null): ?>
       menu-light
         <?php else: ?>
        <?php if(themesetting(Auth::id())->theme == 'light-layout'): ?>
        menu-light
        <?php else: ?>
        menu-dark
        <?php endif; ?>
    <?php endif; ?> 
    menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto"><a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">
                    <h2 class="brand-text"> <?php echo e(__('Admin')); ?></h2>
                </a></li>
            <li class="nav-item nav-toggle">
                <a id="toggle" class="nav-link modern-nav-toggle pr-0" data-toggle="collapse">
                    <i class="d-block d-xl-none text-primary toggle-icon font-medium-4" data-feather="x"></i>
                    <i class="d-none d-xl-block collapse-toggle-icon font-medium-4  text-primary" data-feather="disc" data-ticon="disc"></i>
                </a>
            </li> 
        </ul>
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(route('dashboard')); ?>"><i data-feather="home"></i><span class="menu-title text-truncate" data-i18n="Dashboards">Dashboards</span><span class="badge badge-light-warning badge-pill ml-auto mr-1"></span></a>
               
            </li>
            <li class=" navigation-header"><span data-i18n="Apps &amp; Pages">Apps &amp; Pages</span><i data-feather="more-horizontal"></i>
            </li>
            

            

            <li class=" nav-item"><a  class="<?php echo $__env->yieldContent('header'); ?> d-flex align-items-center" href="<?php echo e(route('headertextview')); ?>"><i data-feather='clipboard'></i><span class="menu-title text-truncate" data-i18n="Service">Update Banner</span></a>
                
            </li>

            


            <li class=" nav-item"><a class="<?php echo $__env->yieldContent('service'); ?> d-flex align-items-center" href="#"><i data-feather='cpu'></i><span class="menu-title text-truncate" data-i18n="Service">Service</span></a>
                <ul class="menu-content">
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('admin.serviceview')); ?>"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List">Create</span></a>
                    </li>
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('admin.servicetableview')); ?>"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Preview">List</span></a>
                    </li>
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('admin.updateserviceview')); ?>"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Preview">Update Service</span></a>
                    </li>
                </ul>
            </li>



            
            <li class=" nav-item"><a class="<?php echo $__env->yieldContent('team'); ?> d-flex align-items-center" href="#"><i data-feather='users'></i><span class="menu-title text-truncate" data-i18n="Service">Team</span></a>
                <ul class="menu-content">
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('admin.teamview')); ?>"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List">Create</span></a>
                    </li>
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('admin.teamtable')); ?>"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="Preview">List </span></a>
                    </li>
                </ul>
            </li>

            

            

            <li class=" nav-item"><a class="<?php echo $__env->yieldContent('recentwork'); ?> d-flex align-items-center" href="#"><i data-feather="file-text"></i><span class="menu-title text-truncate" data-i18n="Service">Recent Work</span></a>
                <ul class="menu-content">
                    <li><a  class="d-flex align-items-center" href="<?php echo e(route('admin.addrecentwork')); ?>"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List"> Create</span></a>
                    </li>

                    <li><a class="d-flex align-items-center" href="<?php echo e(route('admin.managerecentwork')); ?>"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List"> List</span></a>
                    </li>

                    <li><a class="d-flex align-items-center" href="<?php echo e(route('recentwork.button.show')); ?>"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List"> Update Button</span></a>
                    </li>
                   
                </ul>
            </li>

               

               

               <li class=" nav-item"><a class=" <?php echo $__env->yieldContent('feedback'); ?> d-flex align-items-center" href="#"><i data-feather='frown'></i><span class="menu-title text-truncate" data-i18n="Service">Client Feedback</span></a>
                <ul class="menu-content">
                    <li><a  class="d-flex align-items-center" href="<?php echo e(route('feedback.addview')); ?>"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List"> Create</span></a>
                    </li>

                    <li><a class="d-flex align-items-center" href="<?php echo e(route('feedback.show')); ?>"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List">List</span></a>
                    </li>
                    
                </ul>
            </li>

            

            
            <li class=" nav-item"><a class=" <?php echo $__env->yieldContent('clientmessage'); ?> d-flex align-items-center" href="#"><i data-feather='message-square'></i><span class="menu-title text-truncate" data-i18n="Service">Client Message</span></a>
                <ul class="menu-content">
                    <li><a  class="d-flex align-items-center" href="<?php echo e(route('customer.message.show')); ?>"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List"> Show Message</span></a>
                    </li>

                
                </ul>
            </li>

            

            <li class=" nav-item"><a class=" <?php echo $__env->yieldContent('projectarea'); ?> d-flex align-items-center" href="<?php echo e(route('project.area.updateview')); ?>"><i data-feather='rss'></i><span class="menu-title text-truncate" data-i18n="Service">Update Project</span></a>
                
            </li>

            

            <li class=" nav-item"><a class=" <?php echo $__env->yieldContent('experiencearea'); ?> d-flex align-items-center" href="<?php echo e(route('experience.area.updateview')); ?>"><i data-feather='dribbble'></i><span class="menu-title text-truncate" data-i18n="Service">Update About Us</span></a>
            </li>

            

            <li class=" nav-item"><a class=" <?php echo $__env->yieldContent('contact'); ?> d-flex align-items-center" href="<?php echo e(route('contact.updateview')); ?>"><i data-feather='phone-forwarded'></i><span class="menu-title text-truncate" data-i18n="Service">Update Contact</span></a>
                
            </li>
            <li class=" nav-item"><a class=" <?php echo $__env->yieldContent('trust'); ?> d-flex align-items-center" href="#"><i data-feather='sunset'></i><span class="menu-title text-truncate" data-i18n="Service">Trust Us</span></a>
                <ul class="menu-content">
                    <li><a  class="d-flex align-items-center" href="<?php echo e(route('trust.addview')); ?>"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List">Create</span></a>
                    </li>

                    <li><a  class="d-flex align-items-center" href="<?php echo e(route('trust.show')); ?>"><i data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List">List</span></a>
                    </li>
                   
                
                </ul>
            </li>

            

            <li class=" nav-item"><a class=" <?php echo $__env->yieldContent('title'); ?> d-flex align-items-center" href="<?php echo e(route('title.show')); ?>"><i data-feather='type'></i><span class="menu-title text-truncate" data-i18n="Service">Update Title</span></a>
            </li>

            
                <li class=" nav-item"><a class=" <?php echo $__env->yieldContent('social_url'); ?> d-flex align-items-center" href="<?php echo e(route('social.url.update.view')); ?>"><i data-feather='link'></i></i><span class="menu-title text-truncate" data-i18n="Service">Social Url Update</span></a>
                </li>

                <li class=" nav-item"><a class=" <?php echo $__env->yieldContent('copyright'); ?> d-flex align-items-center" href="<?php echo e(route('copyright.update.view')); ?>"><i data-feather='clipboard'></i><span class="menu-title text-truncate" data-i18n="Service">Update Copyright</span></a>
                </li> <br> 
                
            

        </ul>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
    $(document).ready(function(){
        $('#dark').click(function(){
            $.ajax({
                url: "<?php echo e(route('theme.color')); ?>",
                type: "GET",
                success: function(data){
                }
            })
        });

        $('#toggle').click(function(){
        $.ajax({
            url: "<?php echo e(route('theme.toggle')); ?>",
            type: "GET",
            success: function(data)
            {
            
            }
                
        })
    });

    })
</script> 





<?php /**PATH D:\laravel_all_project\consultancy-4\resources\views/backend/includes/mainmenu.blade.php ENDPATH**/ ?>