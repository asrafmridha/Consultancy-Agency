
<?php $__env->startSection('team','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <h2 class="content-header-title float-left mb-0">Admin Dashboard</h2>
    <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="">Team Table </a>
            </li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 

<div class="d-flex justify-content-between">
    <div class="row">
        <form action=" <?php echo e(route('team-file-export')); ?> " method="POST"> 
         <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary m-1">Export</button>
        </form>
        <button data-toggle="modal" data-target="#teamcsvModal" type="submit" class="btn btn-primary m-1 btn-sm" style="height: 40px">Import</button>    
    </div>
</div>


<div class="card-body">
    <form action="<?php echo e(route('team.date.filter')); ?>" method="GET">
        <div class="row align-items-end">
            <div class="col-md">
                <div class="form-group">
                    <label for="start_date">Start Date <span class="text-danger">*</span></label>
                    <input type="date" name="start_date" <?php if(isset(request()->start_date)): ?> value="<?php echo e(\Carbon\Carbon::parse(request()->start_date)->format('Y-m-d')); ?>" <?php endif; ?> id="start_date" class="form-control flatpickr-human-friendly" placeholder="dd/mm/yyyy">
                </div>
            </div>
            <div class="col-md">
                <div class="form-group">
                    <label for="start_date">End Date <span class="text-danger">*</span></label>
                    <input type="date" <?php if(isset(request()->start_date)): ?> value="<?php echo e(\Carbon\Carbon::parse(request()->end_date)->format('Y-m-d')); ?>" <?php endif; ?> name="end_date" id="end_date" class="form-control flatpickr-human-friendly" placeholder="dd/mm/yyyy">
                </div>
            </div>
             <div class="col-md-auto">
                <div class="form-group">
                    <button type="submit" class="btn btn-success waves-effect w-100 w-sm-auto">Filter</button>
                </div>
            </div>
        </div>
    </form>
    <form action="<?php echo e(route('team.table.search')); ?>"  method="GET">
         <div class="row align-items-md-center">
            <div class="col-md">
                <div class="form-group mb-md-0">
                    <div class="input-group">
                        <input type="search" name="search" class="form-control table_search" placeholder="Search Here By Name Or Designation" required>
                        <div class="input-group-append">
                          <span class="input-group-text">
                            <button type="submit" class="btn btn-sm" style="height: 23px"><i data-feather='search'></i></button>
                          </span>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
     </form>
</div>




<div class="row" id="dark-table">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Team Member (<?php echo e($data->count()); ?>)</h4>
            </div> 
            <div class="table-responsive">
                <table class="table table-white"  >
                    <thead>
                        <?php if($data->isEmpty()): ?>
                        <h2 class=" d-inline offset-5 alert alert-danger">Data Not Found</h2>
                        <?php else: ?>
                        <tr>
                            <th>Sl No</th>
                            <th>image</th>
                            <th>name</th>  
                            <th>Designation</th>
                            <th>fb_link</th>
                            <th>twitter_link</th>
                            <th>linkedin_link</th>
                            <th>pinterest_link</th>
                            <th colspan="2">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                            <?php $slno=1; ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <tr>
                                <td><?php echo e($slno); ?></td>
                                <td>
                                    <div class="avatar-group">
                                        <div data-toggle="tooltip" data-popup="tooltip-custom" data-placement="top" title="" class="avatar pull-up my-0" data-original-title="<?php echo e($item->name); ?>">
                                            <img height="80px" width="100px" src="<?php echo e(asset('uploads/team/'.$item->image)); ?>" alt="">
                                        </div> 
                                    </div>
                                </td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->designation); ?></td>
                                <td><?php echo e($item->fb_link); ?></td>
                                <td><?php echo e($item->twitter_link); ?></td>
                                <td><?php echo e($item->linkedin_link); ?></td>
                                <td><?php echo e($item->pinterest_link); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button type="button" class="btn btn-sm text-dark dropdown-toggle hide-arrow" data-toggle="dropdown">
                                            <i data-feather="more-vertical"></i>
                                        </button>
                                        <div class="dropdown-menu">
                                            <button data-target="#updateModalteam__<?php echo e($item->id); ?>" data-toggle="modal" type="submit" class="dropdown-item" href="javascript:void(0);">
                                                <i data-feather="edit-2" class="mr-50"></i>
                                                <span>Edit</span>
                                            </button>
                                            <button data-target="#deleteModalteam__<?php echo e($item->id); ?>" data-toggle="modal" type="submit" class="dropdown-item" href="javascript:void(0);">
                                                <i data-feather="trash" class="mr-50"></i>
                                                <span>Delete</span>
                                            </button>
                                        </div>
                                    </div>
                                </td>

                                <!-- Modal for Service Update -->
                                <div class="modal fade" id="updateModalteam__<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Confirmation Message</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                        
                                            <div class="modal-body">
                                                <form action="<?php echo e(Route('admin.team.update',$item->id)); ?>"  method="POST" enctype="multipart/form-data" >
                                                        <?php echo csrf_field(); ?>
                                                        <label for="">Old Image</label>
                                                        <img height="100px" width="100px" src="<?php echo e(asset('uploads/team/'.$item->image)); ?>" alt="img nai">
                                                        <input type="file" name="image" class="mt-3 form-control name">
                                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger">
                                                            <?php echo e($message); ?>

                                                        </div>  
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        <input type="text" name="name" value="<?php echo e($item->name); ?>" class="mt-3 form-control name" placeholder="Enter Team Member name">
                                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger">
                                                            <?php echo e($message); ?>

                                                        </div>  
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                        <input type="text" name="designation" class="mt-3 form-control image"
                                                        placeholder="Enter Designation" value="<?php echo e($item->designation); ?>">
                                                        <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger">
                                                            <?php echo e($message); ?>

                                                        </div>  
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        <input type="text" name="fb_link" class="mt-3 form-control" placeholder="Enter  Fb link here" value="<?php echo e($item->fb_link); ?>">
                                                        <?php $__errorArgs = ['fb_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger">
                                                    
                                                            <?php echo e($message); ?>

                                                        </div>  
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                                        <input type="text" name="twitter_link" class="mt-3 form-control" placeholder="Enter  Twitter link here" value="<?php echo e($item->twitter_link); ?>">
                                        
                                                        <?php $__errorArgs = ['twitter_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger">
                                                    
                                                            <?php echo e($message); ?>

                                                        </div>  
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                                        <input type="text" name="linkedin_link" class="mt-3 form-control" placeholder="Enter  Linkedin link here" value="<?php echo e($item->linkedin_link); ?>">
                                                        <?php $__errorArgs = ['linkedin_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger">
                                                    
                                                            <?php echo e($message); ?>

                                                        </div>  
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        <input type="text" name="pinterest_link" class="mt-3 form-control" placeholder="Enter  Pinterest link here" value="<?php echo e($item->pinterest_link); ?>">
                                                
                                                        <?php $__errorArgs = ['pinterest_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger">
                                                    
                                                            <?php echo e($message); ?>

                                                        </div>  
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        <div class="modal-footer">
                                                            <a type="button" class="btn btn-secondary" data-dismiss="modal">Close</a>
                                                            <button type="submit" class="btn btn-primary deletemodalservicebutton">Update</button>
                                                        </div>
                                            </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            

                                <!-- Modal for Service delete -->
                                <div class="modal fade" id="deleteModalteam__<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Confirmation Message</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                        
                                            <div class="modal-body text-white bg-dark">
                                                <form action="<?php echo e(route('admin.teamdata.destroy',$item->id)); ?>" method="POST">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                    Are you sure want to delete this Service?
                                                    <div class="modal-footer">
                                                        <a type="button" class="btn btn-secondary" data-dismiss="modal">Close</a>
                                                        <button type="submit" class="btn btn-primary deletemodalservicebutton">Confirm</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </tr>
                            <?php $slno++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>  
        </div>
    </div>
</div>
 
<?php $__env->stopSection(); ?>
        
<div class="modal fade" id="teamcsvModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('team-file-import')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <input type="file" name="file" class="mt-3 form-control import" >
                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>  
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
                </form>
        </div>
    </div>
</div>





     



<?php echo $__env->make('backend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/backend/pages/teamtable.blade.php ENDPATH**/ ?>