
<?php $__env->startSection('content'); ?>

<section class="sub-banner section-gap">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h1 class="sub-banner__title text-uppercase font-weight-bold">Contact Us</h1>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb bg-transparent justify-content-center mb-0">
                      <li class="breadcrumb-item"><a href="./index.html" class="breadcrumb-link">Home</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Contact</li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</section>

<section class="contact section-gap">
    <div class="container">
        <div class="row justify-content-center section-space pt-0">
            <div class="col-xl-7 col-lg-6 col-md-10">
                <div class="contact__image-wrapper text-center">
                    <img src="<?php echo e(asset('frontend')); ?>/assets/images/contact/contact-image.png" alt="Contact Image" class="contact__image img-fluid">
                </div>
            </div>

            
           
            <div class="col-xl-5 col-lg-6 col-md-10 mt-5 mt-lg-0 d-flex align-items-end">

                <?php if(session()->has('message')): ?>
                <div class="h2 alert alert-danger">
                <?php echo e(session()->get('message')); ?>

                </div>
                <?php endif; ?>
                    
                <form action="<?php echo e(route('store.customermessage')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="section-header text-center text-lg-left col-12">
                                    <h3 class="section-header__sub-title side-line side-line--81 mb-1"><?php echo e($title->contact_title); ?></h3>
                                    <h1 class="section-header__title text-uppercase font-weight-bold"><?php echo e($title->contact_heading); ?></h1>      
                                </div>
                        <div class="form-group col-12">
                            <input type="text" class="form-control shadow-none h-auto" placeholder="your name"  name="customer_name">
                            <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </div>
                        <div class="form-group col-12">
                            <input type="email" class="form-control shadow-none h-auto" placeholder="your e-mail"  name="customer_email">

                            <?php $__errorArgs = ['customer_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12">
                            <textarea class="form-control form-control--textarea shadow-none" placeholder="your message"  name="customer_message"></textarea>

                            <?php $__errorArgs = ['customer_message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12">
                           <button class="primary-btn d-inline-block text-uppercase border-0 w-100" type="submit">Send Message</button> 

                            
                        </div>
                    </div>
                </form>                
            </div>
        </div>
        <div class="row" data-aos="fade-up">
            <div class="col-lg-12 col-md-10 mx-auto">
                <div class="contact__card bg-white">
                    <div class="contact__card-wrapper">
                        <div class="contact__card-wrapper__block mb-5 mb-xl-0">
                            <div class="contact__card__block">
                                <div class="section-header text-center text-lg-left">
                                    <h3 class="section-header__sub-title mb-1"><?php echo e($title->mail_title); ?></</h3>
                                    <h1 class="section-header__title text-uppercase font-weight-bold"><?php echo e($title->mail_heading); ?></h1>
                                </div>
                                <div class="contact-details text-center text-lg-left d-flex flex-column flex-lg-row align-items-center">
                                    <span class="contact-details__icon d-flex align-items-center justify-content-center rounded-circle flex-shrink-0 text-white mb-2 mb-lg-0">
                                        
                                        <?php echo $contact->email_font; ?>

                                    </span>
                                    <div>
                                        <a href="mailto:consultancyagency@consult.com" class="footer__block__list__link d-inline-block"><?php echo e($contact->email); ?></a><br>
                                        <a href="mailto:consult@consultancyagency.com" class="footer__block__list__link d-inline-block"><?php echo e($contact->alter_email); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="contact__card-wrapper__block contact__card-wrapper__block--line mb-5 mb-xl-0 d-xl-flex justify-content-xl-center position-relative">
                            <div class="contact__card__block">
                                <div class="section-header text-center text-lg-left">
                                    <h3 class="section-header__sub-title mb-1"><?php echo e($title->phone_title); ?></h3>
                                    <h1 class="section-header__title text-uppercase font-weight-bold"><?php echo e($title->phone_heading); ?></h1>
                                </div>
                                <div class="contact-details text-center text-lg-left d-flex flex-column flex-lg-row align-items-center">
                                    <span class="contact-details__icon d-flex align-items-center justify-content-center rounded-circle flex-shrink-0 text-white mb-2 mb-lg-0">
                                        
                                        <?php echo $contact->phone_font; ?>

                                    </span>
                                    <div>
                                        <a href="tel:+5391235862145" class="footer__block__list__link d-inline-block"><?php echo e($contact->phone); ?></a><br>
                                        <a href="tel:+8801234586987" class="footer__block__list__link d-inline-block"><?php echo e($contact->alter_phone); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="contact__card-wrapper__block">
                            <div class="contact__card__block">
                                <div class="section-header text-center text-lg-left">
                                    <h3 class="section-header__sub-title mb-1"><?php echo e($title->location_title); ?></h3>
                                    <h1 class="section-header__title text-uppercase font-weight-bold"><?php echo e($title->location_heading); ?></h1>
                                </div>
                                <div class="contact-details text-center text-lg-left d-flex flex-column flex-lg-row align-items-center">
                                    <span class="contact-details__icon d-flex align-items-center justify-content-center rounded-circle flex-shrink-0 text-white mb-2 mb-lg-0">
                                        
                                        <?php echo $contact->address_font; ?>

                                    </span>
                                    <address class="footer__block__list__address contact-details__text mb-0"><?php echo e($contact->address); ?></address>	
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>







        
    </div>
</section>


<?php $__env->stopSection(); ?> 



<?php echo $__env->make('frontend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>