
 
<?php $__env->startSection('service','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <h2 class="content-header-title float-left mb-0">Admin Dashboard</h2>
    <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="">Service Table </a>
            </li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 

<div class="d-flex justify-content-between">
  <div class="row">
      <form action=" <?php echo e(route('service-export')); ?> " method="POST"> 
       <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-primary m-1">Export</button>
      </form>
      <button data-toggle="modal" data-target="#csvModal" type="submit" class="btn btn-primary m-1 btn-sm" style="height: 40px">Import</button>    
  </div>
</div>
 
<div class="card-body">
  <form action="<?php echo e(route('service.date.filter')); ?>" method="GET">
      <div class="row align-items-end">
          <div class="col-md">
              <div class="form-group">
                  <label for="start_date">Start Date <span class="text-danger">*</span></label>
                  <input type="date" name="start_date" <?php if(isset(request()->start_date)): ?> value="<?php echo e(\Carbon\Carbon::parse(request()->start_date)->format('Y-m-d')); ?>" <?php endif; ?> id="start_date" class="form-control flatpickr-human-friendly" placeholder="dd/mm/yyyy">
              </div>
          </div>
          <div class="col-md">
              <div class="form-group">
                  <label for="start_date">End Date <span class="text-danger">*</span></label>
                  <input type="date" <?php if(isset(request()->start_date)): ?> value="<?php echo e(\Carbon\Carbon::parse(request()->end_date)->format('Y-m-d')); ?>" <?php endif; ?> name="end_date" id="end_date" class="form-control flatpickr-human-friendly" placeholder="dd/mm/yyyy">
              </div>
          </div>
           <div class="col-md-auto">
              <div class="form-group">
                  <button type="submit" class="btn btn-success waves-effect w-100 w-sm-auto">Filter</button>
              </div>
          </div>
      </div>
    </form>
    <form action="<?php echo e(route('service.table.search')); ?>" method="GET">
       <div class="row align-items-md-center">
          <div class="col-md">
              <div class="form-group mb-md-0">
                  <div class="input-group">
                      <input type="search" name="search" class="form-control table_search" placeholder="Search Here">
                      <div class="input-group-append">
                        <span class="input-group-text">
                          <button type="submit"><i data-feather='search'></i></button>
                        </span>
                      </div>
                  </div>
              </div>
          </div>
      </div> 
    </form>
</div>



<!-- White Tables start -->
<div class="row" id="dark-table">
  <div class="col-12">
      <div class="card">
          <div class="table-responsive">
            
              <table class="table table-white " >
                  <thead>
                    <?php if($alldata->isEmpty()): ?>
                        <th><h2 class="alert alert-danger">Data Not Found</h2></th>
                        <?php else: ?>  
                      <tr> 
                        <th class="text-dark">Icon</th>
                        <th class="text-dark">Title</th>
                        <th class="text-dark">Short Description</th>
                        <th class="text-dark">Button Text</th>
                        <th class="text-dark">Details</th>
                        <th class="text-dark">Action</th>
                      </tr>
                  </thead>
                  <tbody>
                   <?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td>      <?php echo e($item->icon); ?>                  </td>
                    <td>      <?php echo e($item->title); ?></td>
                    <td>      <?php echo $item->Short_description; ?>    </td>
                    <td>      <?php echo e($item->button_text); ?>             </td>
                    <td><a class="btn btn-primary btn-sm" href="<?php echo e(route('service.details',$item->id)); ?>">See Details</a></td>
                    <td>
                      <div class="dropdown">
                             <button type="button" class="btn btn-sm text-dark dropdown-toggle hide-arrow" data-toggle="dropdown">
                             <i data-feather="more-vertical"></i>
                             </button>
                            <div class="dropdown-menu">
                                  <a  href="<?php echo e(route('service.edit',$item->id)); ?>"   class="dropdown-item" href="javascript:void(0);">
                                  <i data-feather="edit-2" class="mr-50"></i>
                                  <span>Edit</span>
                                  </a>
                                  <button data-target="#deleteModalteam_<?php echo e($item->id); ?>" data-toggle="modal" type="button" class="dropdown-item" href="javascript:void(0);"data-category="<?php echo e($item->id); ?>">
                                  <i data-feather="trash" class="mr-50"></i>
                                  <span>Delete</span>
                                  </button>
                            </div>
                      </div>
                  </td>

                  
                  <div class="modal fade" id="deleteModalteam_<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Confirmation Message</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                                  <div class="modal-body">
                                      <form action="<?php echo e(route('admin.deleteservice', $item->id
                                      )); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field("delete"); ?>
                                            Are you sure want to delete this Service?
                                            <div class="modal-footer">
                                                <a type="button" class="btn btn-secondary" data-dismiss="modal">Close</a>
                                                <button type="submit" class="btn btn-primary deletemodalservicebutton">Confirm</button>
                                            </div>
                                      </form>
                                  </div>
                          </div>
                    </div>
                  </div>

                  
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    <?php endif; ?> 
                  </tbody>
              </table>
            
              <?php echo e($alldata->links()); ?> 
          </div>
      </div>
  </div>
</div>
<!-- White Tables end -->

<!-- Modal For Import CSV -->
<div class="modal fade" id="csvModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
              </div>
                  <div class="modal-body">
                      <form action="<?php echo e(route('service-file-import')); ?>" method="POST" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                      <input type="file" name="file" class="mt-3 form-control import" >
                  </div>
                  <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                      <button type="submit" class="btn btn-primary">Save</button>
                  </div>
              </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/backend/pages/servicetable.blade.php ENDPATH**/ ?>