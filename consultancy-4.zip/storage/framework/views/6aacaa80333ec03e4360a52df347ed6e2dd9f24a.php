
 
<?php $__env->startSection('service','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <h2 class="content-header-title float-left mb-0">Admin Dashboard</h2>
    <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="">Service Table Details </a>
            </li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- White Tables start -->
<div class="row" id="dark-table">
    <div class="col-12">
        <div class="card">
            <div class="table-responsive" >
                <table class="table table-white" >
                    <thead>
                        <tr> 
                            <th class="text-dark">Short Description 2</th>
                            <th class="text-dark">advise</th>
                            <th class="text-dark">advisor_name</th>
                            <th class="text-dark">Heading</th>
                            <th class="text-dark">point</th>
                            <th class="text-dark">Image</th>
                            <th class="text-dark">Main Page</th>                  
                            <th class="text-dark">Action</th>                  
                        </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>      <?php echo $item->short_description2; ?>    </td>
                        <td>      <?php echo e($item->advise); ?>                  </td>
                        <td>      <?php echo e($item->advisor_name); ?>             </td>
                        <td>      <?php echo e($item->heading); ?>                </td>
                        <td>      <?php echo $item->point; ?>                 </td>
                        <td><img height="80px" width="120px" src="<?php echo e(asset('uploads/service/'.$item->image)); ?>" alt=""> </td> 
                        <td><a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.servicetableview')); ?>">See Main</a></td>
                      <td>
                        <div class="dropdown">
                               <button type="button" class="btn btn-sm text-dark dropdown-toggle hide-arrow" data-toggle="dropdown">
                               <i data-feather="more-vertical"></i>
                               </button>
                              <div class="dropdown-menu">
                                    <a  href="<?php echo e(route('service.edit',$item->id)); ?>"   class="dropdown-item" href="javascript:void(0);">
                                    <i data-feather="edit-2" class="mr-50"></i>
                                    <span>Edit</span>
                                    </a>
                                    <button data-target="#deleteModalteam_<?php echo e($item->id); ?>" data-toggle="modal" type="button" class="dropdown-item" href="javascript:void(0);"data-category="<?php echo e($item->id); ?>">
                                    <i data-feather="trash" class="mr-50"></i>
                                    <span>Delete</span>
                                    </button>
                              </div>
                        </div>
                    </td>
  
                    
                    <div class="modal fade" id="deleteModalteam_<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-centered" role="document">
                          <div class="modal-content">
                              <div class="modal-header">
                                  <h5 class="modal-title" id="exampleModalLabel">Confirmation Message</h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                  </button>
                              </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('admin.deleteservice', $item->id
                                        )); ?>" method="post">
                                              <?php echo csrf_field(); ?>
                                              <?php echo method_field("delete"); ?>
                                              Are you sure want to delete this Service?
                                              <div class="modal-footer">
                                                  <a type="button" class="btn btn-secondary" data-dismiss="modal">Close</a>
                                                  <button type="submit" class="btn btn-primary deletemodalservicebutton">Confirm</button>
                                              </div>
                                        </form>
                                    </div>
                            </div>
                      </div>
                    </div>
  
                    
                      </tr>  
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
  <!-- White Tables end -->



<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_all_project\consultancy-4\resources\views/backend/pages/service_details_table.blade.php ENDPATH**/ ?>