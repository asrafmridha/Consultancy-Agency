

<?php $__env->startSection('experiencearea','active'); ?>


<?php $__env->startSection('content'); ?>

<div class="col-md-6" style="margin-top: 100px; margin-left:400px">
   

    <h2 class="content-header-title float-left mb-0">Admin Dashboard</h2>
    <div class="breadcrumb-wrapper">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('dashboard')); ?>">Home</a>
        </li>
        <li class="breadcrumb-item">
            <a href="#">Experience Area </a>
        </li>
       
    </ol>
</div>



<input type="file" name="image" class="mt-1 form-control name" >
<?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
   <div class="alert alert-danger">

       <?php echo e($message); ?>

   </div>  
   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/backend/experience/addimage.blade.php ENDPATH**/ ?>