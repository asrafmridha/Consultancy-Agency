<section class="services section-gap">
    <div class="container">
        <div class="row">
            <div class="section-header col-12 text-center">
                <h3 class="section-header__sub-title side-line side-line--38 mb-1">Our Services</h3>
                <h1 class="section-header__title text-uppercase font-weight-bold">Buisness & Finance Consulting</h1>
            </div>

            <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 d-flex" data-aos="fade-up">
                <div class="services__block position-relative">
                    <div class="services__block__top d-flex align-items-center">
                        <div class="services__block__icon d-inline-flex flex-shrink-0 align-items-center justify-content-center position-relative">
                            <i class="flaticon-stats position-relative"></i>
                        </div>
                        <h3 class="services__block__title mb-0"><?php echo e($item->title); ?></h3>
                    </div>
                    <p class="services__block__text"><?php echo e($item->Short_description); ?></p>
                    <a href="./service-details.html" class="services__block__btn d-inline-flex align-items-center stretched-link"><?php echo e($item->button_text); ?><i class="btn__icon flaticon-straight-right-arrow position-relative"></i></a>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>
        </div>
    
</section><?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/frontend/includes/ourservices.blade.php ENDPATH**/ ?>