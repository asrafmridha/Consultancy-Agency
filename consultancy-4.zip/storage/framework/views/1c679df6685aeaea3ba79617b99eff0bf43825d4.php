

<?php $__env->startSection('projectarea','active'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <h2 class="content-header-title float-left mb-0">Admin Dashboard</h2>
    <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="">Update Feedback</a>
            </li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
<section >
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

    <form action="<?php echo e(Route('project.area.update',$data->id)); ?>"  method="POST" >
     <?php echo csrf_field(); ?>
 
       
    <label class="mt-1 h5" for="heading">Enter Heading</label>
    <input type="text" name="heading" class="text-dark  form-control name" placeholder="Enter Heading" value="<?php echo e($data->heading); ?>">

        <?php $__errorArgs = ['heading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger">

            <?php echo e($message); ?>

        </div>  
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label class="mt-1 h5" for="title">Enter Title</label>
        <input type="text" name="title" class=" text-dark  form-control image"
        placeholder="Enter Title" value="<?php echo e($data->title); ?>">

        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger">
    
            <?php echo e($message); ?>

        </div>  
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        <label class="mt-1 h5" for="button_text">Button Text</label>
        <input type="text" name="button_text" class=" text-dark  form-control image"
        placeholder="Enter Title" value="<?php echo e($data->button_text); ?>">

        <?php $__errorArgs = ['button_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger">
    
            <?php echo e($message); ?>

        </div>  
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <button class="form-control mt-1 btn-purchaseAdd btn btn-primary"> Update</button>

    </form>
           </div>
        </div>
     </div>
  </div>
</section>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_all_project\consultancy-4\resources\views/backend/project/projectarea.blade.php ENDPATH**/ ?>