
 
<?php $__env->startSection('recentwork','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <h2 class="content-header-title float-left mb-0">Admin Dashboard</h2>
    <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="">Team Table </a>
            </li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>









<div class="row" id="dark-table">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
               <h4 class="card-title">Recent Work (<?php echo e($data->count()); ?>)</h4>
            </div>
                <div class="table-responsive">
                     <table class="table table-white display" id="table_id">
                        <thead>
                            <?php if($data->isEmpty()): ?>
                            <th><h2 class="alert alert-danger">Data Not Found</h2></th>
                            <?php else: ?>
                            <tr>
                                <th class="text-dark">Image</th>
                                <th class="text-dark">Title</th>
                                <th class="text-dark">Short Description</th>
                                <th colspan="2" class="text-dark">Action</th>
                            </tr>
                            </thead>
                            <tbody class="servicetable">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                        <tr>
                                <td>
                                <div class="avatar-group">
                                    <div data-toggle="tooltip" data-popup="tooltip-custom" data-placement="top" title="" class="avatar pull-up my-0" data-original-title="<?php echo e($item->title); ?>">
                                      <img height="80px" width="100px" src="<?php echo e(asset('uploads/recentwork/'.$item->image)); ?>" alt="">
                                    </div> 
                                </div>
                                </td>
                                <td class="text-dark"><?php echo e($item->title); ?></td>
                                <td class="text-dark"><?php echo $item->short_description; ?>  </td> 
                                <td>
                            <div class="dropdown">
                                <button type="button" class="btn btn-sm text-dark dropdown-toggle hide-arrow" data-toggle="dropdown">
                                    <i data-feather="more-vertical"></i>
                                </button>
                                <div class="dropdown-menu">
                                    <button data-target="#recentworkupdatemodal__<?php echo e($item->id); ?>" data-toggle="modal" type="submit" class="dropdown-item" href="javascript:void(0);">
                                        <i data-feather="edit-2" class="mr-50"></i>
                                        <span>Edit</span>
                                    </button>
                                    <button data-target="#deleterecentworkModal_<?php echo e($item->id); ?>" data-toggle="modal" type="button" class="dropdown-item" href="javascript:void(0);"   data-category="<?php echo e($item->id); ?>">
                                      <i data-feather="trash" class="mr-50"></i>
                                      <span>Delete</span>
                                  </button>
                                </div>
                            </div>
                        </tr> 
                     
                <div class="modal fade" id="recentworkupdatemodal__<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Confirmation Message</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('admin.updaterecentwork',$item->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>       
                                    <img height="100px" width="100px" src="<?php echo e(asset('uploads/recentwork/'.$item->image)); ?>" alt="">
                                    <input type="file" name="image" class="form-control mt-1">
                                    <label for="title">Enter Title Here</label>
                                    <input value="<?php echo e($item->title); ?>" name="title" type="text"  class=" title form-control name" placeholder="Enter title name">
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger">
                                           <?php echo e($message); ?>

                                        </div>  
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <label for="title" class="mt-1">Enter Short Description Here</label>
                                    <input value="<?php echo e($item->short_description); ?>" name="short_description" type="text"  class=" title form-control name" placeholder="Enter Team Member name">
                                    <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger">
                                        <?php echo e($message); ?>

                                    </div>  
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   
                                    <div class="modal-footer">
                                            <a type="button" class="btn btn-secondary" data-dismiss="modal">Close</a>
                                            <button type="submit" class="serviceupdatebutton btn btn-primary deletemodalservicebutton">Confirm</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div> 



                <!-- Modal for recent Work delete -->
                    <div class="modal fade" id="deleterecentworkModal_<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Confirmation Message</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(route('admin.deleterecentwork', $item->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("delete"); ?>
                                         Are you sure want to delete this Service?
                      
                                    <div class="modal-footer">
                                        <a type="button" class="btn btn-secondary" data-dismiss="modal">Close</a>
                                        <button type="submit" class="btn btn-primary deletemodalservicebutton">Confirm</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                        </tbody>
                    </table> 
            </div>
        </div>
    </div>
</div>
      
    
<!-- Modal For Import CSV -->
<div class="modal fade" id="csvModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('recentwork-file-import')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <input type="file" name="file" class="mt-3 form-control import" >  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>

  // jQuery(document).ready(function(){

  //   show();
  //   function show(){
  //     $.ajax({
  //       type: "GET",
  //       url: "/admin/servicetabledata",
  //       dataType: "JSON",
  //       success: function (response) {
  //        var data = "";
  //         $.each(respons.alldata, function (key, item) { 

  //           data+='<tr>\
  //             <td>'+item.title+'</td>\
  //             <td>'+item.Short_description+'</td>\
  //             <td>'+item.button_text+'</td>\
  //               <td><button id="updatebtn" value="'+item.id+'" class="updateproduct btn btn-success btn-sm" data-toggle="modal" data-target="#updateproduct"><i class="fa fa-edit"></i></button> </td>\
  //               <td> <button value="'+item.id+'" class="deleteproduct btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteModalproduct"><i class="fa fa-trash"></i></button></td>\
  //             </tr>';
             
  //         });
  //       }
  //     });

  //     jQuery(".servicetable").html(data);


  //   }



//   });








 
</script>


<?php echo $__env->make('backend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_all_project\consultancy-4\resources\views/backend/pages/recentwork/recent_work_table.blade.php ENDPATH**/ ?>