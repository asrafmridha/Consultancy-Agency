
 
<?php $__env->startSection('recentwork','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <h2 class="content-header-title float-left mb-0">Admin Dashboard</h2>
    <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="">Recent Work Button</a>
            </li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('recentwork.button.update',$recentworkbutton->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="buisness_finance">Enter Buisness and Finance Button Text</label>
                        <input type="text" name="buisness_finance" id="recentworkbutton" class="form-control" placeholder="Enter Buisness and Finance Button Text" value="<?php echo e($recentworkbutton->buisness_finance); ?>" />
                        <?php $__errorArgs = ['buisness_finance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="customer_support">Enter Customer Support Button Text</label>
                        <input type="text" name="customer_support" id="customer_support" class="form-control" placeholder="Enter Customer Support Button Text" value="<?php echo e($recentworkbutton->customer_support); ?>" />
                        <?php $__errorArgs = ['customer_support'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="financial_service">Enter  Financial Service Button Text</label>
                        <input type="text" name="financial_service" id="financial_service" class="form-control" placeholder="Enter Financial Service Button Text" value="<?php echo e($recentworkbutton->financial_service); ?>" />
                        <?php $__errorArgs = ['financial_service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="buisness_stargey">Enter  Business Strategy Button Text</label>
                        <input type="text" name="buisness_stargey" id="buisness_stargey" class="form-control" placeholder="Enter Business Strategy Button Text" value="<?php echo e($recentworkbutton->buisness_stargey); ?>" />
                        <?php $__errorArgs = ['buisness_stargey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="sale_service">Enter  Sales Service Button Text</label>
                        <input type="text" name="sale_service" id="sale_service" class="form-control" placeholder="Enter Sales Service Button Text" value="<?php echo e($recentworkbutton->sale_service); ?>" />
                        <?php $__errorArgs = ['sale_service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button class="form-control mt-1 btn-purchaseAdd btn btn-primary"> Update</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/backend/pages/recentwork/recent_work_button.blade.php ENDPATH**/ ?>