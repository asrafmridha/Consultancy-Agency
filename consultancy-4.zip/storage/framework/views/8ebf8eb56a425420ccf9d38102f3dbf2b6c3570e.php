

<?php $__env->startSection('social_url','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <h2 class="content-header-title float-left mb-0">Admin Dashboard</h2>
    <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="">Social Url</a>
            </li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
            <form action="<?php echo e(route('social.url.update',social_url()->id)); ?> " method="POST">
                <?php echo csrf_field(); ?>
                
                <div class="form-group">
                    <label for="fb_url">Enter Facebook Url</label>
                    <input type="text" name="fb_url" id="fb_url" class="form-control" placeholder="Enter Facebook Url" value="<?php echo e(social_url()->fb_url); ?>" />
                    <?php $__errorArgs = ['fb_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="twitter_url">Enter Twitter Url</label>
                    <input type="text" name="twitter_url" id="twitter_url" class="form-control" placeholder="Enter Twitter Url" value="<?php echo e(social_url()->twitter_url); ?>" />
                    <?php $__errorArgs = ['twitter_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="pinterest_url">Enter Pinterest Url</label>
                    <input type="text" name="pinterest_url" id="pinterest_url" class="form-control" placeholder="Enter Pinterest Url" value="<?php echo e(social_url()->pinterest_url); ?>" />
                    <?php $__errorArgs = ['pinterest_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="linkedin_url">Enter Linkedin Url</label>
                    <input type="text" name="linkedin_url" id="linkedin_url" class="form-control" placeholder="Enter Linkedin Url" value="<?php echo e(social_url()->linkedin_url); ?>" />
                    <?php $__errorArgs = ['linkedin_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button class="form-control mt-1 btn-purchaseAdd btn btn-primary"> Update</button>
            </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/backend/social/social_url.blade.php ENDPATH**/ ?>