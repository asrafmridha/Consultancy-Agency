<!-- All CSS -->
<link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/plugins/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/fonts/flaticon/flaticon.css">
<link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/plugins/slick-slider/css/slick.css">
<link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/plugins/venobox/css/venobox.min.css">
<link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/plugins/aos/css/aos.css">
<link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/style.css"><?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/frontend/includes/css.blade.php ENDPATH**/ ?>