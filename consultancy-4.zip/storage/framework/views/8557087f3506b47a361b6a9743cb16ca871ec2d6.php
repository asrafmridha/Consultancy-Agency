
 
<?php $__env->startSection('trust','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <h2 class="content-header-title float-left mb-0">Admin Dashboard</h2>
    <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="">Table</a>
            </li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section >
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Trust Us  (<?php echo e($data->count()); ?>)</h4>
                    <div class="table-responsive">
                        <table class="table table-white">
                        <thead>
                            <tr>
                                <th>Sl No</th>
                                <th>Image</th>   
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $slno=1; ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
                            <tr>
                                <td><?php echo e($slno); ?></td>
                                <td> <img src="<?php echo e(asset('uploads/trustus/'.$item->image)); ?>" alt=""></td>
                                

                            <td>                            
                            <div class="dropdown">
                                <button type="button" class="btn btn-sm text-dark dropdown-toggle hide-arrow" data-toggle="dropdown">
                                    <i data-feather="more-vertical"></i>
                                </button>
                                <div class="dropdown-menu">
                                    <button data-target="#updateModaltrust__<?php echo e($item->id); ?>" data-toggle="modal" class="dropdown-item" href="javascript:void(0);">
                                        <i data-feather="edit-2" class="mr-50"></i>
                                        <span>Edit</span>
                                    </button>
                                    <button data-target="#deleteModaltrust__<?php echo e($item->id); ?>" data-toggle="modal" type="submit" class="dropdown-item" href="javascript:void(0);">
                                        <i data-feather="trash" class="mr-50"></i>
                                        <span>Delete</span>
                                    </button>
                                </div>
                            </div>
                            </td> 
                           </tr>
                           <?php $slno++; ?>


        <!-- Modal for Trust Us Section  delete -->
<div class="modal fade" id="deleteModaltrust__<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Confirmation Message</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div> 
            <div class="modal-body text-white bg-dark">
              <form action="<?php echo e(route('trust.destroy',$item->id)); ?>" method="POST">
                <?php echo method_field('delete'); ?>
                  <?php echo csrf_field(); ?>
                      Are you sure want to delete this Service?
                    
                    <div class="modal-footer">
                        <a type="button" class="btn btn-secondary" data-dismiss="modal">Close</a>
                        <button type="submit" class="btn btn-primary deletemodalservicebutton">Confirm</button>
                    </div>
              </form>
            </div>
      </div>
  </div>
</div>

<!-- Modal for Trust Us Section  Update -->
<div class="modal fade" id="updateModaltrust__<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Confirmation Message</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div> 
      <div class="modal-body text-white bg-dark">
        <form action="<?php echo e(route('trust.update',$item->id)); ?>" method="POST" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="">Old Image</label> <br>
                 <img class="bg-white"  src="<?php echo e(asset('uploads/trustus/'.$item->image)); ?>" alt=""> <br> <br>
                  <div class="custom-file">
                 <input type="file" class="custom-file-input" id="customFile" name="image" />
                 <label class="custom-file-label" for="customFile">Choose file</label>
                 </div>
                 <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                 <small class="text-danger"><?php echo e($message); ?></small>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="form-control mt-1 btn-purchaseAdd btn btn-primary"> Update</button>
            
        </form>
        </div>
  </div>
</div>
</div>












                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                        </table>

                </div>
            </div>
        </div>
   </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/backend/trust/show.blade.php ENDPATH**/ ?>