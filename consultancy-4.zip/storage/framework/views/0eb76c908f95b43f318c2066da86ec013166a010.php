

<?php $__env->startSection('feedback','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <h2 class="content-header-title float-left mb-0">Admin Dashboard</h2>
    <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="">Update Feedback</a>
            </li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(Route('feedback.update',$data->id)); ?>"  method="POST" enctype="multipart/form-data" >
     <?php echo csrf_field(); ?>

      <label  class="mt-1 mr-5 h5 " for="old_image"> oldImage</label><br>

      <img class="mr-5" height="150px" width="150px" src="<?php echo e(asset('uploads/client/'.$data->image)); ?>" alt="Something Went Wrong"><br>
 
      <label class="mt-1 h5" for="old_image"> New Image</label>
     <input type="file" name="image" class="mt-1 form-control name" >
     <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger">

            <?php echo e($message); ?>

        </div>  
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      
        <label class="mt-1 h5" for="short_description">Enter Short Description</label>
        <input type="text" name="short_description" class="text-dark  form-control name" placeholder="Enter Short Description" value="<?php echo $data->short_description; ?>">

        <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger">

            <?php echo e($message); ?>

        </div>  
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label class="mt-1 h5" for="client_name">Enter Client Name</label>
        <input type="text" name="client_name" class=" text-dark  form-control image"
        placeholder="Enter Client Name" value="<?php echo e($data->client_name); ?>">

        <?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger">
    
            <?php echo e($message); ?>

        </div>  
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        
        <label class="mt-1 h5" for="designation">Enter Client Designation</label>
        <input type="text" name="designation" class=" text-dark  form-control image"
        placeholder="Enter Client Name" value="<?php echo e($data->designation); ?>">

        <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger">
            <?php echo e($message); ?>

        </div>  
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <select class="mt-2 form-control" name="star">
           <option value="">-----Select Star-----</option>
           <option value="1" <?php if($data->star==1): ?>selected <?php endif; ?>>1</option> 
           <option value="2" <?php if($data->star==2): ?>selected <?php endif; ?>>2</option> 
           <option value="3" <?php if($data->star==3): ?>selected <?php endif; ?>>3</option> 
           <option value="4" <?php if($data->star==4): ?>selected <?php endif; ?>>4</option> 
           <option value="5" <?php if($data->star==5): ?>selected <?php endif; ?>>5</option>
        </select>
        
        <?php $__errorArgs = ['star'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger">
    
            <?php echo e($message); ?>

        </div>  
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <button type="submit" class="form-control mb-3 btn-purchaseAdd btn btn-success"> Update</button>
    </form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('backend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/backend/clientfeedback/update_show.blade.php ENDPATH**/ ?>