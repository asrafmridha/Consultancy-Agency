


<?php $__env->startSection('service','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <h2 class="content-header-title float-left mb-0">Admin Dashboard</h2>
    <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="">Service Update </a>
            </li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section >
    <div class="row">
        <div class="col-12">
            <div class="card"> 
               <div class="card-body">

                <form action="<?php echo e(route('service.update',$item->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
      
                  <label for="icon">Enter Icon Here</label>
                  <input value="<?php echo e($item->icon); ?>" name="icon" type="text"  class="icon title form-control name" placeholder="Enter Team Member name">
                  
                  <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-danger">
          
                      <?php echo e($message); ?>

                  </div>  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                  <label for="Short_description">Enter Title Here</label>
                  <input value="<?php echo e($item->title); ?>" name="title" type="text"  class="Short_description title form-control name" placeholder="Enter Team Member name">
                  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-danger">
          
                      <?php echo e($message); ?>

                  </div>  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <label for="Short_description"><?php echo e(__("Enter Short Description Here")); ?> <span class="text-danger"> *</span></label>

                  <input id="Short_description" value="<?php echo $item->Short_description ?? old('Short_description'); ?>" type="hidden" name="Short_description">
                  <trix-editor input="Short_description" class="trix-content"></trix-editor> 
                    <?php $__errorArgs = ['Short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                  <label for="button_text" class="mt-1">Enter Button Text</label>
                  <input value="<?php echo e($item->button_text); ?>" name="button_text" type="text"  class="button_text form-control name" placeholder="Enter Team Member name">
          
                  <?php $__errorArgs = ['button_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-danger">
          
                      <?php echo e($message); ?>

                  </div>  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          
                  <label for="icon">Old Image</label>
                  <img height="80px" width="120px" src="<?php echo e(asset('uploads/service/'.$item->image)); ?>" alt=""> <br>
                
          
                  <label for="image">New Image</label> 
                  <input type="file" name="image"> <br> <br>
          
                  <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-danger">
          
                      <?php echo e($message); ?>

                  </div>  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          
                  <label for="short_description2"><?php echo e(__("Enter Short Description2 Here")); ?> <span class="text-danger"> *</span></label>
                  <input type="hidden" name="short_description2" id="short_description2" value="<?php echo $item->short_description2; ?>" class="form-control">
                  <trix-editor input="short_description2" style="min-height: 6rem !important"><?php echo $item->short_description2; ?></trix-editor>
                  <?php $__errorArgs = ['short_description2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="text-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                  <label for="advise">Advise</label>
                  <input value="<?php echo e($item->advise); ?>" name="advise" type="text"  class="advise title form-control name" placeholder="Enter Team Member name">
                  
                  <?php $__errorArgs = ['advise'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-danger">
          
                      <?php echo e($message); ?>

                  </div>  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          
                  <label for="advisor_name">Advisor Name</label>
                  <input value="<?php echo e($item->advisor_name); ?>" name="advisor_name" type="text"  class="advisor_name title form-control name" placeholder="Enter Team Member name">
                  
                  <?php $__errorArgs = ['advisor_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-danger">
          
                      <?php echo e($message); ?>

                  </div>  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          
                  <label for="heading">Heading</label>
                  <input value="<?php echo e($item->heading); ?>" name="heading" type="text"  class="heading title form-control name" placeholder="Enter Team Member name">
                  
                  <?php $__errorArgs = ['heading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-danger">
          
                      <?php echo e($message); ?>

                  </div>  
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          
                  <label for="point"><?php echo e(__("point")); ?> <span class="text-danger"> *</span></label>
                  <input type="hidden" name="point" id="point"  class="form-control" value="<?php echo $item->point; ?>">
                  <trix-editor  input="point" style="min-height: 6rem !important"><?php echo $item->point; ?></trix-editor>
                  <?php $__errorArgs = ['point'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="text-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                  <button type="submit" class="form-control btn btn-primary "> Update</button>
              </form>
               </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.mastaring.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DCL\OneDrive\Desktop\soclose-2\consultancy\resources\views/backend/pages/service_edit_view.blade.php ENDPATH**/ ?>